function deleteFormById(formId, message, isRecycleMode = false) {
  var confirmButtonText;
  if (isRecycleMode) {
    confirmButtonText = {
      confirmButtonText: 'بله ، بازیافت شود !',
    }
  } else {
    confirmButtonText = {
      confirmButtonText: 'بله ، حذف شود !',
    }
  }

  Swal.fire({
    title: message,
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    ...confirmButtonText,
    cancelButtonText: 'خیر',
  }).then((result) => {
    if (result.value) {
      var tag = document.getElementById(formId)
      console.log(tag)
      $("#" + formId).submit()
    }
  });
}


function deleteForm(route, message, isDeleteMode) {
  var form = document.createElement("form");

  if (route.includes("?")) {
    var separator = "&"
  } else {
    separator = "?";
  }


  var target = "";
  if (isDeleteMode) {
    target = route + separator + "mode=delete";
  } else {
    target = route + separator + "mode=restore";
  }
  form.action = target;

  form.method = "POST";
  form.style.display = "none";
  var csrf = document.createElement("input");
  csrf.value = $("#csrf").attr("content");
  csrf.name = "_token";
  form.appendChild(csrf);

  var method = document.createElement("input");
  method.value = "DELETE";
  method.name = "_method";
  form.appendChild(method);
  document.body.appendChild(form);


  if (isDeleteMode) {
    confirmButtonText = {
      confirmButtonText: 'بله!',
    }
  } else {
    confirmButtonText = {
      confirmButtonText: 'بله!',
    };
  }

  Swal.fire({
    title: message,
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    ...confirmButtonText,
    cancelButtonText: 'خیر',
  }).then((result) => {
    if (result.value) {
      form.submit();
    }
  });

}

var urls = [];
var allTags = $(".sidebar-menu a");
var i;
for (i = 0; i < allTags.length; i++) {
  urls.push($(allTags[i]));
}


var currentUrl = window.location.href;
$('.sidebar-submenu').removeClass('active')
for (i = 0; i < urls.length; i++) {
  var tag = urls[i];
  var url = urls[i].attr('href');
  if (url == currentUrl) {
    tag.parent().parent().parent().addClass('active');
    tag.parent().addClass('active');
  }
}

function setupEditor(id, locale = "fa") {
  CKEDITOR.config.language = locale;
  CKEDITOR.config.filebrowserUploadUrl = "/admin/upload-image";
  CKEDITOR.config.filebrowserBrowseUrl = "/admin/upload-image";
  CKEDITOR.config.filebrowserUploadMethod = "form";
  CKEDITOR.config.skin = 'office2013';
  CKEDITOR.config.extraPlugins = ['html5audio', 'html5video'];

  CKEDITOR.replace(id)
}


$(".select-checkbox").click(function () {
  var allCheckboxes = $(".select-checkbox");
  var selectedCheckboxes = allCheckboxes.filter(":checked");
  if (selectedCheckboxes.length > 0) {
    $(".multipleDelete").removeClass("disabled");
  } else {
    $(".multipleDelete").addClass("disabled");
  }
});

$(function () {
  var allCheckboxes = $(".select-checkbox");
  var selectedCheckboxes = allCheckboxes.filter(":checked");
  if (selectedCheckboxes.length > 0) {
    $(".multipleDelete").removeClass("disabled");
  }
});

function multipleDelete(route, name, mode) {
  var allCheckboxes = $(".select-checkbox");
  var selectedCheckboxes = allCheckboxes.filter(":checked");
  if (selectedCheckboxes.length > 0) {
    var title = "";
    if (mode === "delete") {
      title = name + " های انتخاب شده به سطل زباله منتقل شوند؟";
    } else if (mode === "deleteForEver") {
      title = name + " های انتخاب شده برای همیشه حذف شوند؟";
    } else if (mode === "restore") {
      title = name + "  های انتخاب شده بازیابی شوند؟ ";
    }

    var parameters = $("#recycle-form").attr("data-parameters");
    if (parameters) {
      if (route.includes("?")) {
        parameters = JSON.parse(parameters)
        var result = getQueryParameters(parameters, "");
        result = result.replace("?", "&");
        route += result;
      }
    }

    $("#recycle-form").attr("action", route);
    Swal.fire({
      title: title,
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'بله!',
      cancelButtonText: 'خیر',
    }).then((result) => {
      if (result.value === true)
        $("#recycle-form").submit();
    });

  } else {
    warningMessage("هیچ آیتمی انتخاب نشده است")
  }
}

function multipleChange(route, name, fillable) {
  var allCheckboxes = $(".select-checkbox");
  var title = "وضعیت "  + name + " های انتخاب شده تغییر پیدا کند؟ ";
  var selectedCheckboxes = allCheckboxes.filter(":checked");
  if (selectedCheckboxes.length > 0) {

    route = "/admin/" + route + "/-1?type=switch&fillable=" + fillable
    $("#recycle-form").attr("action", route);
    Swal.fire({
      title: title,
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'بله!',
      cancelButtonText: 'خیر',
    }).then((result) => {
      if (result.value === true)
        $("#recycle-form").submit();
    });

  } else {
    warningMessage("هیچ آیتمی انتخاب نشده است")
  }
}

function successMessage(message) {
  Swal.fire({
    title: message,
    type: "success",
    confirmButtonColor: '#3085d6',
    confirmButtonText: 'بسیار خب',
  }).then((result) => {
  });
}

function warningMessage(message) {
  Swal.fire({
    title: message,
    type: "warning",
    confirmButtonColor: '#3085d6',
    confirmButtonText: 'بسیار خب',
  }).then((result) => {
  });
}

$(function () {
  setupActions();
});


function isRecycleBinMode() {
  var path = (window.location.href).trim().replace(" ", "");
  return path.includes("recycle-bin=true") || path.includes("recycle-bin=1");
}

function setupActions() {
  var actions = $("td.actions");
  for (var i = 0; i < actions.length; i++) {
    var action = actions[i];
    var name = action.getAttribute("data-name");
    var route = action.getAttribute("data-route");
    var id = action.getAttribute("data-id");

    var parameters = action.getAttribute("data-parameters");
    if (parameters) {
      parameters = JSON.parse(parameters);
    }

    if (action.hasAttribute("data-delete")) {
      var deleteTag;
      if (isRecycleBinMode()) {
        deleteTag = getRestoreRoute(name, route, id, parameters);
      } else {
        deleteTag = getDeleteRoute(name, route, id, parameters);
      }
      action.append(deleteTag)
    }
    if (action.hasAttribute("data-edit")) {
      var editTag = getEditRoute(name, route, id, parameters);
      action.append(editTag)
    }
  }
}

//function getQueryLink($routeData, $routePrefix, $isRecycleBin = false)
// {
//   $i = 0;
//   if ($isRecycleBin) {
//     $routePrefix .= "?recycle-bin=true";
//     $i++;
//   }
//   foreach ($routeData as $key => $value) {
//
//
//     if ($i == 0) {
//       $routePrefix .= "?" . $key . "=" . $value;
//     } else {
//       $routePrefix .= "&" . $key . "=" . $value;
//     }
//     $i++;
//   }
//   return $routePrefix;
//
// }

function getQueryParameters(routeData, routePrefix, isRecycleBin = false) {
  var count = 0;
  if (isRecycleBin) {
    routePrefix += "?recycle-bin=true";
    count++;
  }
  for (var rd in routeData) {
    if (count === 0) {
      routePrefix += "?" + rd + "=" + routeData[rd];
    } else {
      routePrefix += "&" + rd + "=" + routeData[rd];
    }
  }
  return routePrefix;

}

function getEditRoute(name, route, id, parameters) {

  var title = " ویرایش " + name;
  var a = document.createElement("a");
  a.setAttribute("data-toggle", "tooltip");
  a.setAttribute("data-placement", "bottom");
  a.setAttribute("title", title);
  a.classList.add("fa");
  a.classList.add("fa-edit");
  if (isRecycleBinMode())
    a.href = getQueryParameters(parameters, "/admin/" + route + "/" + id + "/edit", true);
  else
    a.href = getQueryParameters(parameters, "/admin/" + route + "/" + id + "/edit", false);
  return a;
}

function getDeleteRoute(name, route, id, parameters) {
  var title = name + " به سطل زباله منتقل شود؟";
  var _route = getQueryParameters(parameters, "/admin/" + route + "/" + id, false);
  var span = document.createElement("span");
  span.setAttribute("data-toggle", "tooltip");
  span.setAttribute("data-placement", "bottom");
  span.setAttribute("title", "حذف " + name);
  span.classList.add("fa");
  span.classList.add("fa-trash");
  span.setAttribute("onclick", "deleteForm('" + _route + "','" + title + "',true)");
  return span;
}

function getRestoreRoute(name, route, id, parameters) {
  var title = name + " بازیابی شود؟";
  var _route = getQueryParameters(parameters, "/admin/" + route + "/" + id, false);
  var span = document.createElement("span");
  span.setAttribute("data-toggle", "tooltip");
  span.setAttribute("data-placement", "bottom");
  span.setAttribute("title", "بازیابی " + name);
  span.classList.add("fa");
  span.classList.add("fa-refresh");
  span.setAttribute("onclick", "deleteForm('" + _route + "','" + title + "',false)");
  return span;
}

function setNumericInput(querySelector) {
  new Cleave(querySelector, {
    numeral: true,
    numeralThousandsGroupStyle: 'thousand'
  });
}


function numberFormat(x) {
  x = x.toString();
  var pattern = /(-?\d+)(\d{3})/;
  while (pattern.test(x))
    x = x.replace(pattern, "$1,$2");
  return x;
}
