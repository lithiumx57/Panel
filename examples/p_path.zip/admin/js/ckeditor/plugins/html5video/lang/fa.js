CKEDITOR.plugins.setLang( 'html5video', 'fa', {
    button: 'وارد کردن ویدیوی HTML5',
    title: 'ویدیوی HTML5',
    infoLabel: 'اطلاعات ویدیو',
    allowed: 'پسوندهای مجاز فایل: MP4, WebM, Ogv',
    urlMissing: 'URL منبع ویدیو پیدا نشد.',
    videoProperties: 'خواهص ویدیو',
    upload: 'بارگذاری',
    btnUpload: 'ارسال به سرور',
    advanced: 'پیشرفته',
    autoplay: 'پخش خودکار؟',
    allowdownload: 'Allow download?',
    advisorytitle: 'Advisory title',
    yes: 'بله',
    no: 'خیر',
    responsive: 'عرض واکنشگرا',
    controls: 'نمایش کنترل؟'
} );
