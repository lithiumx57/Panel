CKEDITOR.plugins.setLang( 'html5audio', 'ru', {
    button: 'Вставить HTML5 аудио',
    title: 'HTML5 аудио',
    infoLabel: 'Аудио',
    urlMissing: 'Не выбран источник аудио',
    audioProperties: 'Свойства аудио',
    upload: 'Загрузить',
    btnUpload: 'Загрузить на сервер',
    advanced: 'Дополнительно',
    autoplay: 'Автовоспроизведение',
    allowdownload: 'Разрешить загрузку',
    advisorytitle: 'Заголовок',
    yes: 'Да',
    no: 'Нет'
} );
