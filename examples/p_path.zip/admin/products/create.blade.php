@extends('admin.layouts.main')

@section('style')

  <style>

    #gift-container {
      display: none;
    }

    #gift-container.active {
      display: block;
    }

    .bootstrap-select .dropdown-menu li a {
      padding: 4px
    }

    .tagItem {
      background: rgba(71, 71, 71, .3);
      padding: 8px 8px 8px 30px;
      position: relative;
      display: inline-block;
      margin: 4px;
      border-radius: 4px;
    }

    .tagItem .removeItem {
      position: absolute;
      left: 2px;
      cursor: pointer;
      transition: color 300ms;
      top: 2px
    }

    .tagItem .removeItem:hover {
      color: #ff4444
    }

  </style>

@endsection
@section('content')
  @include('admin.layouts.error')
  @include('admin.layouts.options',getOptions("Product",text(TEXT_PRODUCT),text(TEXT_PRODUCTS),"products"))
  <form action="{{route('admin.products.store')}}" method="post" enctype="multipart/form-data">
    @csrf
    <div class="form-group col-md-12 col-xl-8">
      <label for="title">نام محصول</label>
      <input type="text" class="form-control" id="title" name="title" value="{{old('title')}}">
    </div>

    <div class="form-group col-md-12 col-xl-8">
      <label for="e_title">نام محصول ( انگلیسی )</label>
      <input type="text" class="form-control ltr" id="e_title" name="e_title" value="{{old('e_title')}}">
    </div>

    <div class="form-group col-md-12 col-xl-8">
      <label for="label">عنوان نمایش در دسته بندی</label>
      <input type="text" class="form-control" id="label" name="label" value="{{old('label')}}">
    </div>

    <div class="form-group col-md-12 col-xl-8">
      <label for="e_label">عنوان نمایش در دسته بندی ( انگلیسی )</label>
      <input type="text" class="form-control ltr" id="e_label" name="e_label" value="{{old('e_label')}}">
    </div>

    <div class="form-group col-md-12 col-xl-8">
      <label for="category_id">دسته بندی</label>
      <select name="category_id" id="category_id" class="selectpicker" data-live-search="true">
        @foreach($categories as $category)
          <option @if(old('parent') && old('parent')==$category->id) selected @endif value="{{$category->id}}">
            {{$category->parentCategory->label}} --> {{$category->label}}
          </option>
        @endforeach
      </select>
    </div>

    <div class="form-group col-md-12 col-xl-8">
      <label for="brand_id">برند</label>
      <select name="brand_id" id="brand_id" class="selectpicker" data-live-search="true">
        @foreach($brands as $brand)
          <option @if(old('brand_id')==$brand->id) selected @endif value="{{$brand->id}}">{{$brand->label}} - {{$brand->name}}</option>
        @endforeach
      </select>
    </div>

    <div class="form-group col-md-12 col-xl-8">
      <label for="status">وضعیت</label>
      <select name="status" id="status" class="selectpicker">
        <option @if(old('status')==\App\Models\Product::STATUS_EXISTS) selected @endif value="{{\App\Models\Product::STATUS_EXISTS}}">موجود</option>
        <option @if(old('status')==\App\Models\Product::STATUS_STOP_PRODUCTION) selected @endif  value="{{\App\Models\Product::STATUS_STOP_PRODUCTION}}">توقیف تولید</option>
        <option @if(old('status')==\App\Models\Product::STATUS_INACTIVE) selected @endif  value="{{\App\Models\Product::STATUS_INACTIVE}}">غیر فعال</option>
        <option @if(old('status')==\App\Models\Product::STATUS_NOT_EXISTS) selected @endif  value="{{\App\Models\Product::STATUS_NOT_EXISTS}}">نا موجود</option>
      </select>
    </div>

    <div class="form-group col-md-12 col-xl-8">
      <label for="has_gift">هدیه</label>
      <select name="has_gift" id="has_gift" class="form-control">
        <option onclick="updateGift(0)" @if(old('has_gift')==0) selected @endif  value="0">این کالا بدون هدیه است</option>
        <option onclick="updateGift(1)" @if(old('has_gift')==1) selected @endif  value="1">این کالا دارای هدیه است</option>
      </select>
    </div>

    <div class="form-group col-md-12 col-xl-8" id="gift-container">
      <label for="gift">عنوان</label>
      <input type="text" class="form-control" id="gift" name="gift" value="{{old('gift')}}">
      <br>
      <label for="">تصویر هدیه</label>
      <input type="file" name="gift_image">
    </div>

    <div class="form-group col-md-12 col-xl-8">
      <label for="colors">رنگ</label>
      <select name="colors[]" id="colors" class="selectpicker" data-live-search="true" multiple title='این محصول بدون رنگ می باشد'>

        @foreach($colors as $color)
          <option
            @php
              $productColors=old('colors');
              if (is_array($productColors))
              foreach ($productColors as $row){
                if ($row==$color->id){
                echo "selected";
                }
              }
            @endphp
            value="{{$color->id}}"
            data-content='<span style="width: 100px;display: inline-block;@if(strtolower($color->code)=="ffffff" || $color->name=="سفید") color:#000 @endif;;;;height: 30px;background: {{"#".$color->code}};line-height:30px;;border-radius: 4px;text-align: center">{{$color->name}}</span>'>
          </option>
        @endforeach
      </select>
    </div>

    <div class="form-group col-md-12 col-xl-8">
      <label for="description">توضیحات</label>
      <textarea type="text" class="form-control" id="description" name="description">{{old('description')}}</textarea>
    </div>
    <br>
    <br>
    <div style="text-align: center;width: 400px;height: 400px;margin: auto;box-shadow:  0 0 2px 0 #ccc">
      <input type="file" style="display: none" id="file" onchange="renderImage(event)" name="image">
      <br>
      <span id="uploadImage" style="width: 100px;display: inline-block;height: 35px;margin: auto" class="btn btn-success">انتخاب تصویر</span>
      <br><br><br>
      <img src="" alt="" style="width: 200px" id="image">
    </div>


    <div class="form-group col-md-12 col-xl-8">
      <label for="tag">تگ ها</label>
      <br>
      <input id="tag" placeholder="جدا کننده ( | )" type="text" class="form-control" style="border-top-left-radius: 0;border-bottom-left-radius: 0;vertical-align: middle;;display: inline-block;width: calc(100% - 80px);float: right">
      <span id="addTag" class="btn btn-success" style="width: 70px;border-top-right-radius: 0;border-bottom-right-radius: 0;float: right;height: 38px;;vertical-align: middle">افزودن</span>
      <input type="hidden" name="tags" id="tags" value="{{old('tags')}}">
    </div>

    <br><br>
    <div class="form-group col-md-12 col-xl-8">
      <div id="t_container">
      </div>
    </div>
    <br>
    <br>


    <div class="form-group col-md-8 col-xs-12">
      <input type="submit" class="btn btn-primary" value="ثبت">
    </div>
  </form>



@endsection

@section('script')
  @include('admin.layouts.bs')
  <script src="{{asset('admin/js/ckeditor/ckeditor.js')}}"></script>
  <script>
    @if(old('has_gift'))
    updateGift(1)
    @endif

    $("#has_gift").on("change", function () {
      var value = parseInt($(this).val())
      if (value === 0) {
        $("#gift-container").removeClass("active")
      } else {
        $("#gift-container").addClass("active")
      }
    })

    function updateGift(value) {
      if (value === 0) {
        $("#gift-container").removeClass("active")
      } else {
        $("#gift-container").addClass("active")
      }
    }


    setupEditor("description");
    var tagContainer = $("#t_container");
    var oldTags = '{{old("tags")}}';
    oldTags = oldTags.split("|");
    for (var i = 0; i < oldTags.length; i++) {
      if (oldTags[i].trim().length === 0) {
        continue;
      }
      addTag(oldTags[i]);
    }

    $("#addTag").click(function () {
      var tags = $("#tag").val().trim();
      tags = tags.split("|");

      var tagsInput = $("#tags");
      for (var i = 0; i < tags.length; i++) {
        if (tags[i].trim().length === 0) {
          continue;
        }
        addTag(tags[i]);
        tagsInput.val(tagsInput.val() + "|" + tags[i].trim() + "|");
      }
      $("#tag").val("");
    });

    function addTag(title) {
      var newTag = '<span class="tagItem">\n' +
        '<span>' + title + '</span>\n' +
        '<span class="fa fa-close removeItem" onclick="removeTag(this,\'' + title + '\')"></span>\n' +
        '</span>';
      tagContainer.append(newTag)
    }

    function removeTag(tag, text) {
      var tagsInput = $("#tags");
      var result = tagsInput.val().replace("|" + text + "|", "");
      tagsInput.val(result);
      $(tag).parent().remove();
    }

    $("#uploadImage").click(function (event) {
      event.preventDefault();
      $("#file").click();
    });

    function renderImage(event) {
      var fr = new FileReader();
      fr.readAsDataURL(event.target.files[0])
      fr.onload = function () {
        var image = document.getElementById('image')
        image.src = fr.result;
      };
    }


  </script>
@endsection