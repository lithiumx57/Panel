@extends('admin.layouts.main')
@section('style')
  <link rel="stylesheet" href="{{asset('files/frontend/stores/assets/fa/css/all.css')}}">
@endsection
@section('content')


  <?php
  $data = '<div class="dropdown options" style="display: inline-block;margin-left: 8px">
    <button type="button" style="direction: rtl" class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true">درج محصول</button>
    <div class="dropdown-menu">
      <a  data-toggle="tooltip" data-placement="right" title="" href="' . route('admin.productStores.index') . '" style="width: 238px">
        <i class="fa fa-list"></i>
        <span>همه محصولات ثبت شده در این سایت</span>
      </a>
    </div>
  </div>';
  ?>

  @include('admin.layouts.options',getOptions("Product",text(TEXT_PRODUCT),text(TEXT_PRODUCTS),"products",true,$data))


  <form action="" id="recycle-form" method="post">
    @csrf
    @method('DELETE')

    <div class="table-responsive">
      <table id="default-datatable" class="table table-bordered table-hover">
        <thead>
        <tr>
          <th style="width: 20px !important;">انتخاب</th>
          <th>عنوان</th>
          <th>دسته بندی</th>
          <th>فروشگاه</th>
          <th>تصویر محصول</th>
          <th class="tac">وضعیت</th>
          <th class="tac">عملیات</th>
        </tr>
        </thead>
        <tbody>
        @foreach($products as $product)
          <?php
          $product = $product->product
          ?>
          <tr>
            <td style="width: 20px">
              @if($product->has_gift)
                <i data-toggle="tooltip" data-placement="left" class="fa fa-gift" title="این محصول دارای هدیه است : {{$product->gift}}" style="color: #f44;font-size: 30px;cursor: pointer"></i>
              @endif
              <div style="padding-right: 30px" class="p_child">
                <div class="icheck-material-success">
                  <input type="checkbox" id="success_{{$product->id}}" name="records[]" value="{{$product->id}}" class="select-checkbox">
                  <label style="font-weight: bold" class="f12" for="success_{{$product->id}}"></label>
                </div>
              </div>
            </td>
            <td>{{$product->title}}</td>
            <td>{{$product->category->label}}</td>
            <td>{{$product->store->name}}</td>
            <td><img src="{{$product->getSmallImage()}}" style="width: 100px" alt=""></td>
            <td class="tac">
              <span style="display: inline-block;padding: 4px;border-radius: 4px;text-align: center;background: @if($product->status==\App\Models\Product::STATUS_EXISTS) #00b09b @else #ff4444 @endif">{{$product->getStatus()}}</span>
            </td>
            <td class="tac actions" @if(getStoreId()==$product->store_id) data-delete="true" data-edit="true" @endif data-name="{{text(TEXT_PRODUCT)}}" data-route="products" data-id="{{$product->id}}">
              <a data-toggle="tooltip" data-placement="bottom" title="همه قیمت های این محصول" class="fa fa-dollar" href="{{route('admin.productAmounts.index',['product_id'=>$product->id])}}"></a>
              @if(getStoreId()==$product->store_id)
                <a data-toggle="tooltip" data-placement="bottom" title="همه فیلتر های این محصول" class="fa fa-filter" href="{{route('admin.productFilters.index',['product_id'=>$product->id])}}"></a>
                <a data-toggle="tooltip" data-placement="top" title="گالری تصاویر این محصول" class="fa fa-image" href="{{route('admin.productGallery.index',['product_id'=>$product->id])}}"></a>
                <a data-toggle="tooltip" data-placement="bottom" title="جزئیات محصول" class="fa fa-info" href="{{route('admin.productAttributes.index',['product_id'=>$product->id])}}"></a>
                <a data-toggle="tooltip" data-placement="top" title="نقد و بررسی" class="fa fa-glasses" href="{{route('admin.reviews.index',['product_id'=>$product->id])}}"></a>
              @endif
            </td>
          </tr>

        @endforeach
        </tbody>
      </table>
    </div>
  </form>


@endsection

@section('script')
  <script>
    $(document).ready(function () {
      //Default data table
      $('#default-datatable').DataTable();


      var table = $('#example').DataTable({
        lengthChange: false,
        buttons: ['copy', 'excel', 'pdf', 'print', 'colvis']
      });

      table.buttons().container()
        .appendTo('#example_wrapper .col-md-8:eq(0)');
    });

  </script>
@endsection
