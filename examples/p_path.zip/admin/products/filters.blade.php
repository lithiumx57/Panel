@extends('admin.layouts.main')

@section('style')
  <link rel="stylesheet" href="{{asset('admin/css/bootstrap-select.min.css')}}">
  <style>
    .fa-plus {
      cursor: pointer;
    }

    .fa-close {
      cursor: pointer;
    }

    .addIcon {
      font-size: 40px;
      cursor: pointer;
      color: #00b09b;
    }

    .pointer {
      cursor: pointer
    }

    .mt50 {
      margin-top: 50px
    }

    .sub-filter {
      width: 90%;
      margin-top: 2px;
    }

    .main-filter {
      margin-top: 10px;
    }
  </style>

@endsection

@section('content')
  <form action="{{route('admin.productFilters.store',['product_id'=>$product->id])}}" id="recycle-form" method="post">
    @csrf
    <table class="table table-bordered">
      <tr>
        <td>عنوان</td>
        <td>مقدار</td>
      </tr>
      @foreach($filters as $filter)
        @if($filter->parent!=0) @continue @endif
        @php
          $pFilters=$productFilters->where("filter_id",$filter->id);
          $children=$filter->children;
        @endphp
        <tr>
          <td>
            <label for="">{{$filter->title}} : </label>
          </td>
          <td>
            <select name="filters[{{$filter->id}}][]" id="" class="selectpicker" multiple>
              @foreach($children as $row)
                <option @if($pFilters->contains('value','=',$row->id)) selected @endif value="{{$row->id}}">{{$row->title}}</option>
              @endforeach
            </select>
          </td>
        </tr>
      @endforeach
    </table>
    <input type="submit" value="به روز رسانی" class="btn btn-primary">
  </form>


@endsection

@section('script')
  <script src="{{asset('admin/js/bootstrap-select.min.js')}}"></script>
@endsection

