@extends('admin.layouts.main')
@section('style')

  <style>
    .fa-plus {
      cursor: pointer;
    }

    .fa-close {
      cursor: pointer;
    }

    .addIcon {
      font-size: 40px;
      cursor: pointer;
      color: #00b09b;
    }

    .pointer {
      cursor: pointer
    }

    .mt50 {
      margin-top: 50px
    }

    .sub-attribute {
      width: 90%;
      margin-top: 2px;
    }

    .main-attribute {
      margin-top: 10px;
    }
  </style>

@endsection

@section('content')

  <form action="{{route('admin.productAttributes.store',['product_id'=>$product->id])}}" id="recycle-form" method="post">
    @csrf
    <table class="table table-bordered">
      <tr>
        <td>فعال</td>
        <td>عنوان</td>
        <td>مقدار</td>
        <td>عملیات</td>
      </tr>
      @foreach($attributes as $attribute)
        @if($attribute->parent==0 && $attribute->children->count()!=0) @continue @endif
        @php
          $filter=\App\Models\Filter::where(['attribute_id'=>$attribute->id])->first();
          $pAttributes=$productAttributes->where("attribute_id",$attribute->id)->first();
        @endphp
        <tr>
          <td>
            <div class="icheck-material-success dib">
              <input @if($pAttributes) @if($pAttributes->approved)  checked @endif @else checked @endif type="checkbox" class="chkbox" id="success_{{$attribute->id}}" name="approved[{{$attribute->id}}]" value="1">
              <label style="font-weight: bold" class="f12" for="success_{{$attribute->id}}"></label>
            </div>
          </td>

          <td>
            <span>{{$attribute->title}} : </span>
          </td>
          <td id="attribute_{{$attribute->id}}">
            @if($filter instanceof \App\Models\Filter)
              <?php
              $filters = \App\Models\ProductFilter::where([
                'product_id' => $product->id,
              ])->get();
              ?>
              <select name="filter[{{$attribute->id}}][{{$filter->id}}][]" id="" class="selectpicker" multiple>
                @foreach($filter->children as $row)
                  <option
                    @foreach($filters as $row2)
                    @if($row2->value==$row->id)
                    selected
                    @endif
                    @endforeach
                    value="{{$row->id}}">{{$row->title}}</option>
                @endforeach
              </select>
            @else

              @if($pAttributes==null  || $pAttributes->value==null)
                <input type="text" class="form-control" value="" name="value[{{$attribute->id}}][]"/>
              @else
                @foreach($pAttributes->value as $row)
                  <input style="margin-top: 10px" type="text" class="form-control" value="{{$row}}" name="value[{{$attribute->id}}][]"/>
                @endforeach
              @endif
            @endif
          </td>
          <td>
            @if(!($filter instanceof \App\Models\Filter))
              <i class="fa fa-plus-circle pointer" onclick="addOneMore({{$attribute->id}})"></i>
            @endif
          </td>
        </tr>
      @endforeach
    </table>
    <br>
    <br>
    <br>
    سایر خصوصیات
    <hr>
    <table class="table table-bordered" id="otherAttribute">
      <tr>
        <td>عنوان</td>
        <td>مقدار</td>
        <td>عملیات</td>
      </tr>

      @php
        $i=0;
      @endphp

      @foreach($otherAttributes as $attribute)
        <tr>
          <td><input type="text" class="form-control otherKeys" name="otherKeys[]" value="{{$attribute->key}}"></td>
          <td id="other_{{$i}}">

            @foreach($attribute->value as $row)
              <input style="margin-bottom: 8px" type="text" class="form-control" name="otherValues[{{$i}}][]" value="{{$row}}">
            @endforeach
          </td>
          <td class="tac">
            <i class="fa fa-plus" onclick="addRow({{$i}})"></i>&nbsp;&nbsp;
            <i class="fa fa-close" onclick="deleteOther(this)"></i>
          </td>
        </tr>
        @php $i++ @endphp
      @endforeach
    </table>
    <br>
    <i class="fa fa-plus-square addIcon" id="addMainCategory" onclick="addOtherAttribute()"></i>
    <br><br>
    <input type="submit" value="به روز رسانی" class="btn btn-primary">
  </form>


@endsection

@section('script')
  @include('admin.layouts.bs')
  <script>
    function addOneMore(id) {
      var tag = '<input type="text" class="form-control" value="" name="value[' + id + '][]" style="margin-top: 10px"/>';
      $("#attribute_" + id).append(tag);
    }

    function addOtherAttribute() {
      var keyCount = document.getElementsByClassName("otherKeys").length;
      var tag = '<tr>\n' +
        '<td><input type="text" class="form-control otherKeys" name="otherKeys[]"></td>\n' +
        '<td id="other_' + keyCount + '">' +
        '<input style="margin-bottom: 8px" type="text" class="form-control" name="otherValues[' + keyCount + '][]">' +
        '</td>\n' +
        '<td class="tac">' +
        '<i class="fa fa-plus" onclick="addRow(' + keyCount + ')"></i>&nbsp;&nbsp;' +
        '<i class="fa fa-close" onclick="deleteOther(this)"></i>' +
        '</td>\n' +
        '</tr>';
      $('#otherAttribute').append(tag);
    }

    function deleteOther(tag) {
      $(tag).parent().parent().remove();
    }

    function addRow(id) {
      var tag = '<input style="margin-bottom: 8px" type="text" class="form-control" name="otherValues[' + id + '][]">';
      $("#other_" + id).append(tag)
    }


    $(document).ready(function () {
      var $chkboxes = $('.check_b');
      var lastChecked = null;

      $chkboxes.click(function (e) {
        if (!lastChecked) {
          lastChecked = this;
          return;
        }

        if (e.shiftKey) {
          var start = $chkboxes.index(this);
          var end = $chkboxes.index(lastChecked);

          $chkboxes.slice(Math.min(start, end), Math.max(start, end) + 1).prop('checked', lastChecked.checked);
        }

        lastChecked = this;
      });
    });


    $(document).ready(function () {
      var $chkboxes = $('.chkbox');
      var lastChecked = null;

      $chkboxes.click(function (e) {
        if (!lastChecked) {
          lastChecked = this;
          return;
        }

        if (e.shiftKey) {
          var start = $chkboxes.index(this);
          var end = $chkboxes.index(lastChecked);

          $chkboxes.slice(Math.min(start, end), Math.max(start, end) + 1).prop('checked', lastChecked.checked);
        }

        lastChecked = this;
      });
    });

  </script>

@endsection

