@extends('admin.layouts.main')
@section('content')

  @if($errors->any())
    <div class="col-md-8 col-xs-12">
      <ul class="alert alert-danger admin-error">
        @foreach($errors->all() as $row)
          <li>{{$row}}</li>
        @endforeach
      </ul>
    </div>
  @endif
  <form action="{{url($route)}}" method="post">
    @csrf
    <input type="hidden" name="filters" value="{{json_encode($model::initializedFields())}}">
    @foreach($model::initializedFields() as $key=> $row)
      @if($row->show)
        @if($row->isIntegerField())
          @include('admin.form-controls.int',['row'=>$row,"name"=>$row->fillable])
        @elseif($row->isStringField())
          @include('admin.form-controls.string',['row'=>$row,"name"=>$row->fillable])
        @elseif($row->isTextField())
          @include('admin.form-controls.textarea',['row'=>$row,"name"=>$row->fillable])
        @elseif($row->isBooleanField())
          @include('admin.form-controls.checkbox',['row'=>$row,"name"=>$row->fillable])
        @elseif($row->isForeignField())
          @include('admin.form-controls.foreign',['row'=>$row,"name"=>$row->fillable])
        @elseif($row->isSelectField())
          @include('admin.form-controls.select',['row'=>$row,"name"=>$row->fillable])
        @endif
      @endif
    @endforeach
    <div class="clearfix"></div>
    <div class="form-group col-md-8">
      <button class="btn btn-primary">ذخیره</button>
    </div>
  </form>


@endsection

@section('script')
  <?php
  $isAddedCkEditor = false;
  $isAddedBootstrapSelect = false;

  ?>
  @foreach($model::initializedFields() as $row)
    @if($row->isSmartEditor)
      @if(!$isAddedCkEditor)
        <script src="{{asset('admin/js/ckeditor/ckeditor.js')}}"></script>
        <?php
        $isAddedCkEditor = true;
        ?>
      @endif
    @endif


    @if($row->smartSelect)
      @if(!$isAddedBootstrapSelect)
        <link rel="stylesheet" href="{{asset('admin/css/bootstrap-select.min.css')}}">
        <script src="{{asset('admin/js/bootstrap-select.min.js')}}"></script>
        <?php
        $isAddedCkEditor = true;
        ?>
      @endif
    @endif
  @endforeach

@endsection