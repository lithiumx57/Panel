<div class="navBox">
  <h1 style="direction: rtl">
    <a href="/admin/"><span class="fa fa-home"></span>&nbsp;<span><span>داشبورد</span></span></a>
    @isset($path)
      @foreach($path as $p)
        <span class="fa fa-angle-left"></span>
        @if($p['url']=="")
          <?php $link = ""; ?>
        @else
          <?php $link = "/admin/" . $p['url'] ?>
        @endif
        <a href="{{$link}}"><span><span>{{$p['title']}}</span></span></a>
      @endforeach
      @isset($create)
        <span class="fa fa-angle-left"></span>
        <a href="{{$link}}"><span>{{text(TEXT_CREATE)}} {{$name}} {{text(TEXT_NEW)}}</span></a>
      @endisset
      @isset($edit)
        <span class="fa fa-angle-left"></span>
        <a href="{{$link}}"><span>{{text(TEXT_EDIT)}} {{$name}}</span></a>
      @endisset

      @if(isRecycleBinMode() && !isCreateOrEditMode())
        <span class="fa fa-angle-left"></span>
        <a href=""><span><span>سطل زباله</span></span></a>
      @endif
    @endisset


  </h1>
  @if(isset($showOptions) && $showOptions)
    <div class="dropdown options">
      <button type="button" style="direction: rtl" class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true">
        گزینه ها
      </button>
      <div class="dropdown-menu">
        @if(isCreateOrEditMode())
          <?php
          if (isset($routeData)) {
            $indexRoute = url(getQueryLink($routeData, "/admin/" . $route));
          } else {
            $indexRoute = url("/admin/" . $route);
          }
          ?>
          <a data-toggle="tooltip" data-placement="right" title="مشاهده همه {{$name}} ها" href="{{$indexRoute}}">
            <i class="fa fa-list"></i>
            <span>{{$name}} ها</span>
          </a>
        @else
          <?php
          if (isset($routeData)) {
            $createRoute = url(getQueryLink($routeData, "/admin/" . $route . "/create"));
          } else {
            $createRoute = url("/admin/" . $route . "/create");
          }
          ?>

          <a data-toggle="tooltip" data-placement="right" title="ثبت یک {{$name}} جدید" href="{{isset($routeCreate)?$routeCreate:$createRoute}}">
            <i class="fa fa-pencil"></i>
            <span> ساخت {{$name}} جدید</span>
          </a>
        @endif
        @if(isRecycleBinMode())
          @if(!isCreateOrEditMode())
            <?php
            if (isset($routeData)) {
              $indexLink = url(getQueryLink($routeData, "/admin/" . $route));
            } else {
              $indexLink = url("/admin/" . $route);
            }
            ?>
            <a data-toggle="tooltip" data-placement="right" title="مشاهده همه {{$name}} ها" href="{{$indexLink}}">
              <i class="fa fa-list"></i>
              <span>{{$name}} ها</span>
            </a>
          @endif

          <a data-toggle="tooltip" data-placement="right" title="همه {{$name}} های انتخاب شده برای همیشه حذف می شوند" class="form-item disabled multipleDelete" onclick="multipleDelete('/admin/'+'{{$route}}'+'/-1?recycle-bin=true&mode=deleteForEver','{{$name}}','deleteForEver')">
            <i class="fa fa-remove"></i>
            <span>حذف برای همیشه</span>
          </a>

          <a data-toggle="tooltip" data-placement="right" title="همه ی {{$name}} های انتخاب شده بازیابی می شوند" class="form-item disabled multipleDelete" onclick="multipleDelete('/admin/'+'{{$route}}'+'/-1?recycle-bin=true&mode=restore','{{$name}}','restore')">
            <i class="fa fa-refresh"></i>
            <span>بازیافت {{$name}} ها</span>
          </a>
        @else

          <?php
          if (isset($routeData)) {
            $recycleBinRoute = url(getQueryLink($routeData, "/admin/" . $route, true));
          } else {
            $recycleBinRoute = url(getQueryLink([], "/admin/" . $route, true));
          }
          ?>

          @if(!(isset($hasRecycleBin) && $hasRecycleBin==false))
            <a data-toggle="tooltip" data-placement="right" title="باز کردن سطل زباله برای {{$name}} ها" href="{{$recycleBinRoute}}">
              <i class="fa fa-trash"></i>
              <span> سطل زباله ( {{$count}} )</span>
            </a>
          @elseif((isset($hasRecycleBin) && $hasRecycleBin==true))
              <a data-toggle="tooltip" data-placement="right" title="باز کردن سطل زباله برای {{$name}} ها" href="{{$recycleBinRoute}}">
                <i class="fa fa-trash"></i>
                <span> سطل زباله ( {{$count}} )</span>
              </a>
          @endif

          @if(!isCreateOrEditMode())
            <a data-toggle="tooltip" data-placement="right" title="همه {{$name}} های انتخاب شده به سطل زباله منتقل می شوند" class="form-item disabled multipleDelete" onclick="multipleDelete('/admin/'+'{{$route}}'+'/-1?recycle-bin=true&mode=delete','{{$name}}','delete')">
              <i class="fa fa-remove"></i>
              <span>حذف {{$name}} ها</span>
            </a>
          @endif
        @endif
      </div>
    </div>


  @endif

  @isset($dropdown)
    @if($dropdown!=null)
      {!! $dropdown !!}
    @endif
  @endisset

  <div class="clearfix"></div>
</div>